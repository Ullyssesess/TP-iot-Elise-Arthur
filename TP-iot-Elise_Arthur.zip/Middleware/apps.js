import express from "express";
const app = express()
const port = 3003

'use strict'

  
  import { InfluxDB, Point } from '@influxdata/influxdb-client'
  
  / Environment variables /
  const url = "http://localhost:8086/"
  const token = "SnUR_GGmvagRmg8hZanjskM6mtXaIB-MxgYJRfUbstvKNZhevzQlvXY4KjCHJ6D2wcuzFoWbHFeYUp4KSsTtLA=="
  const org = "585f96e557294739"
  const bucket = "df00a0325a6f8c15"
  

  const influxDB = new InfluxDB({ url, token })

  const writeApi = influxDB.getWriteApi(org, bucket)
  

  writeApi.useDefaultTags({ region: 'west' })


app.post('/api/humidity', (req, res) => {
    let data = "";
    req.on('data', (chunk) => {
        data += chunk;
      });
      req.on('end', () => {
          const frame = JSON.parse(data);
          const code = parseInt("0x" + frame.data.substr(0,2))/10;
          const value = parseInt("0x0" + frame.data.substr(2, 4))/10;
          let alert = "";
          if (frame.data.length > 6) {
              alert = parseInt("0x" + frame.data.substr(6, 4))
          };
          const point1 = new Point('humidity')
            .tag('sensor_id', 'TLM01')
            .floatField('humidity', value)
            .intField('code', code)
            writeApi.writePoint(point1)
            writeApi.flush().then(function () {
                console.log("Write Finished");
              })
      });
})
app.post('/api/temperature', (req, res) => {
    let data = "";
    req.on('data', (chunk) => {
        data += chunk;
      });
      req.on('end', () => {
          const frame = JSON.parse(data);
          const code = parseInt("0x" + frame.data.substr(0,2))/10;
          const value = parseInt("0x0" + frame.data.substr(2, 4))/10;
          let alert = "";
          if (frame.data.length > 6) {
              alert = parseInt("0x" + frame.data.substr(6, 4))
          };
          const point1 = new Point('temperature')
            .tag('sensor_id', 'TLM01')
            .floatField('temperature', value)
            .intField('code', code)
            writeApi.writePoint(point1)
            writeApi.flush().then(function () {
                console.log("Write Finished");
              })
      });
  })


  


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

